#!/usr/bin/python

import sys
import os
import random

from string import *



heavy = (3, 2)
light = (2, 3)
vheavy = (3, 3)
vlight = (2, 2)

periodsPerDay = 8
loads = (heavy, light, vheavy, vlight)

dirName = ''
participants = []
subjects = []
slots = []

subjectLoads = {}
resourceMap = {}

def newSubject(id, load):
	return (id, load)

def getSubjectId(s):
	return s[0]

def getSubjectLoadType(s):
	return s[1]

def getLoadDuration(l):
	return l[0]

def getLoadGroupSize(l):
	return l[1]

def newSlot(day, period):
	return (day, period)

def getSlotDay(s):
	return s[0]

def getSlotPeriod(s):
	return s[1]

def readSubjects(fileName):
	if(not os.path.isfile(fileName)):
		print fileName + ": file does not exist."
		sys.exit(1)

	fin = open(fileName, 'r')
	subjectId = 0
	subjects = []
	while(True):
		line = fin.readline()
		if(line == ''):
			break
		else:
			sline = strip(line)
			if(sline == 'vlight'):
				subjects.append(newSubject(subjectId, vlight))
			elif(sline == 'light'):	
				subjects.append(newSubject(subjectId, light))
			elif(sline == 'heavy'):		
				subjects.append(newSubject(subjectId, heavy))
			elif(sline == 'vheavy'):		
				subjects.append(newSubject(subjectId, vheavy))
		subjectId = subjectId + 1
	fin.close()
	return subjects
	
def readResourceMap(fileName, participants):
	if(not os.path.isfile(fileName)):
		print fileName + ": file does not exist."
		sys.exit(1)

	fin = open(fileName, 'r')
	resourceMap = {}

	numberOfParticipants = 0
	while(True):
		line = fin.readline()
		if(line == ''):
			break
		else:
			fields = str.split(line, "|")
			numberOfSubjects = len(fields)
			for i in range(len(fields)):
				if(strip(fields[i]) == 'Yes'):
					if(numberOfParticipants not in resourceMap):
						resourceMap[numberOfParticipants] = []
					resourceMap[numberOfParticipants].append(subjects[i])
		numberOfParticipants = numberOfParticipants + 1
	fin.close()
	return resourceMap

def setup():
	global subjects
	global slots
	global resourceMap
	global periodsPerDay
	global dirName
	if(len(sys.argv) != 2):
		print 'usage: gen-report.py dirname'
		sys.exit()

	dirName = sys.argv[1]
	if(not os.path.exists(dirName)):
		print dirName + ": directory does not exist."
		sys.exit(1)


	slots = [newSlot(day, period) for day in range(5) for period in range(periodsPerDay)]
	subjects = readSubjects(dirName + '/subjects.csv')
	resourceMap = readResourceMap(dirName + '/resourcemap.csv', participants)

def makeGraph():
	graph = {}
	def haveCommonParticipant(s1, s2):
		for p in range(len(participants)):
			if(s1 in resourceMap[p] and s2 in resourceMap[p]):
				return True
		return False

	for s in subjects:
		graph[s] = []
	for s1 in subjects:
		for s2 in subjects:
			if(s2 not in graph[s1]):
				if(haveCommonParticipant(s1, s2)):
					graph[s1].append(s2)
					graph[s2].append(s1)
	return graph

def areNeighbours(n1, n2, g):
	return n1 in g[n2] # n1 in graph[n2] <=> n2 in graph[n1] by construction

def schedule(graph):
	global participants
	global subjects
	global slots
	global subjectLoads
	global resourceMap

# internal functions - begin

	theSchedule = {x : [] for x in slots}
	def isSlotAvailable(subject, slot):
		day = getSlotDay(slot)
		groupSize = getLoadGroupSize(getSubjectLoadType(subject))
		period = getSlotPeriod(slot)
		if(period > (periodsPerDay - groupSize)):
			return False

		for x in range(groupSize):
			s2list = theSchedule[newSlot(day, period + x)]
			for s2 in s2list:
				if(areNeighbours(subject, s2, graph)):
					return False
		return True

	def isSlotGroupAvailable(subject, slotGroup):
		groupSize = getLoadGroupSize(getSubjectLoadType(subject))
		for slot in slotGroup:
			if(not isSlotAvailable(subject, slot)):
				return False
		return True

	def assignSubjectToSlot(subject, slot):
		groupSize = getLoadGroupSize(getSubjectLoadType(subject))
		for i in range(groupSize):
			theSchedule[newSlot(getSlotDay(slot), getSlotPeriod(slot) + i)].append(subject)

# internal functions - end
	goodChoices = {}
	goodChoices[heavy] = ((0, 2), (1, 3), (2, 4))
	goodChoices[light] = ((0, 2, 4), (1, 2, 3), (0, 1, 2), (2, 3, 4))
	goodChoices[vheavy] = ((0, 2, 4), (1, 2, 3), (0, 1, 2), (2, 3, 4))
	goodChoices[vlight] = ((0, 2), (1, 3), (2, 4))

	for subject in subjects:
		loadType = getSubjectLoadType(subject)
		choices = goodChoices[loadType]
		goodSlotGroups = []
		for choice in choices:
			for period in range(periodsPerDay):
				l2 = []
				for day in choice:
					l2.append(newSlot(day, period))
				goodSlotGroups.append(l2)
		random.shuffle(goodSlotGroups)
		for slotGroup in goodSlotGroups:
			if(isSlotGroupAvailable(subject, slotGroup)):
				for slot in slotGroup:
					assignSubjectToSlot(subject, slot)
				break
				
	return theSchedule

def printResourceMap(matrix):
	for p in participants:
		for s in subjects:
			if(s in matrix[p]):
				print 'Yes |',
			else:
				print 'No  |',
		print

def printSchedule(schedule):
	for day in range(5):
		for period in range(periodsPerDay):
			slot = newSlot(day, period)
			subjects = schedule[slot]
			for subject in subjects:
				print str(getSubjectId(subject)) + ', ',
			print ' | ',
		print

def printScheduleToFile(schedule, fileName):
	fout = open(fileName, 'w')
	for day in range(5):
		periodNumber = 0
		for period in range(periodsPerDay):
			slot = newSlot(day, period)
			subjects = schedule[slot]
			subjectNumber = 0
			for subject in subjects:
				fout.write(str(getSubjectId(subject)))
				if(subjectNumber != len(subjects) - 1):
					fout.write(', ')
				subjectNumber = subjectNumber + 1
			if(periodNumber != periodsPerDay - 1):
				fout.write(' | ')
		fout.write('\n')
		periodNumber = periodNumber + 1
	fout.close()

setup()
g = makeGraph()
sched = schedule(g)
printScheduleToFile(sched, dirName + '/sch.csv')
